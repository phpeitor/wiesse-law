# Template Wiesse & Consultores

[![forthebadge](http://forthebadge.com/images/badges/made-with-html.svg)](https://www.linkedin.com/in/drphp/)
[![forthebadge](http://forthebadge.com/images/badges/built-with-love.svg)](https://www.linkedin.com/in/drphp/)

<a href="https://www.instagram.com/amvsoft.tech/">
  <img src="https://wiesseconsultores.com/img/rev-main-img-2.jpg" alt="Instagram" width="800">
</a>

- Clona este repositorio en tu máquina local utilizando el comando git clone [URL_del_repositorio].
- Abre el archivo index.html en tu navegador web preferido.

```
    .\index.html
```

*If you're interested in knowing the powerlevel configuration to get this prompt, have a look at [this gist](https://github.com/phpeitor/).*
